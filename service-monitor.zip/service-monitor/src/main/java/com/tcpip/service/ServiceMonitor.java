package com.tcpip.service;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** 
 *
 * @author W.P.Roshan
 *         
 * Service Monitor class will manage ServiceBroker
 * 
 */

public class ServiceMonitor extends Thread {	
	
	protected int serverPort = 9000;
	protected ServerSocket serverSocket = null;
	protected boolean isStopped = false;
	protected Thread runningThread = null;
	
	
	private static final Logger logger = LogManager.getLogger(ServiceMonitor.class);
	
    public static final int POLLING_FREQUENCY = 1000;    

    protected boolean isThreadRunning = true;
    
    protected ServicePreparator preparator = ServicePreparator.getSingletonInstance();
    
    
    protected ExecutorService threadPool = Executors.newCachedThreadPool();
    

    public ServiceMonitor() {        
        logger.info(String.format("Service Monitor Starting at %s", System.currentTimeMillis()));
    }

    protected boolean isTimeToRun(ServiceSpecification spec) {
    	
        long timestamp = System.currentTimeMillis();
        
        return spec.isRunning()
                && !spec.isOutage(timestamp)
                && (timestamp >= spec.getTimestampLastRun() + spec.getPollingInterval() * 1000);
    }

    public void run() {        
    	
    	synchronized (this) {
			this.runningThread = Thread.currentThread();
		}
    	
		openServerSocket();
		
		while (!isStopped()) {
			
			Socket clientSocket = null;
			
			try {
				clientSocket = this.serverSocket.accept();
				
			} catch (IOException e) {
				
				if (isStopped()) {
					
					logger.debug("IOExeption occured Server Stopped:",ExceptionUtils.getStackTrace(e));
					
					break;
				}
				throw new RuntimeException("Error accepting client connection", e);
			}
			
		
			try {
                for (String serviceName : preparator.getServiceNames()) {
                    ServiceSpecification specification = preparator.getSpecification(serviceName);
                    if (!isTimeToRun(specification)) {
                        continue;
                    }

                    this.threadPool.execute(new ServiceBroker(serviceName,clientSocket, "Thread Pooled Server"));
                }

                Thread.sleep(POLLING_FREQUENCY);
                
            } catch (Exception e) {
                logger.error("Exception on Broker", e);
            }
		
		}
		
		this.threadPool.shutdown();	

        logger.info(String.format("Service Monitor Stopped at %s", System.currentTimeMillis()));
    }

    public void stopService() {
        isThreadRunning = false;
    }

    
    private synchronized boolean isStopped() {
		return this.isStopped;
	}    

	private void openServerSocket() {
		try {
			this.serverSocket = new ServerSocket(this.serverPort);
		} catch (IOException e) {
			throw new RuntimeException("Cannot open port "+this.serverPort, e);
		}
	}    
    
    public static void main(String argv[]) throws Exception {
        
        final String LOCALHOST = "127.0.0.1";
        
        final String SERVICE_A = "Service-A";
        final String SERVICE_B = "Service-B";
        final String SERVICE_C = "Service-C";
        final String SERVICE_D = "Service-D";

        ServiceMonitor server = new ServiceMonitor();
        
        server.preparator.specificationAdd(new ServiceSpecification(SERVICE_A, LOCALHOST, 9000, true, 1, 2));
        server.preparator.specificationAdd(new ServiceSpecification(SERVICE_B, LOCALHOST, 9020, true, 1, 2));
        server.preparator.specificationAdd(new ServiceSpecification(SERVICE_C, LOCALHOST, 9030, true, 1, 2));
        server.preparator.specificationAdd(new ServiceSpecification(SERVICE_D, LOCALHOST, 9040, true, 1, 2));        
        
        new Thread(server).start();	        
    }
}
