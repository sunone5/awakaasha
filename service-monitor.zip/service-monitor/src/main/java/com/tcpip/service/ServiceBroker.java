package com.tcpip.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.apache.commons.lang.exception.ExceptionUtils;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.Socket;
import java.net.UnknownHostException;

/** 
 *
 * @author W.P.Roshan
 * 
 * ServiceBroker connects to the service and updates timestamp of the last successful attempt
 *        
 */
public class ServiceBroker implements Runnable {
	
	protected Socket clientSocket = null;
	protected String serverText = null;
	
	private static final Logger logger = LogManager.getLogger(ServiceBroker.class);
    
    protected ServiceSpecification configs;
    
    public ServiceBroker(String name,Socket clientSocket, String serverText) throws IOException {
        
    	//get the instance of sigleton class by name
    	configs = ServicePreparator.getSingletonInstance().getSpecification(name);      	 	
    	
    	this.clientSocket = clientSocket;
		this.serverText = serverText;
    }
    
    // Preparing socket to connections
    public void run() {       
    	
    	try {
			InputStream input = clientSocket.getInputStream();
			
			OutputStream output = clientSocket.getOutputStream();
			
			long time = System.currentTimeMillis();
			
			output.write(("HTTP/1.1 200 OK\n\nServiceBroker: "+configs.getService()+" - " + this.serverText + " - " + time + "").getBytes());
			
			output.close();
			input.close();			
			
			logger.info("IOExeption occured :"+ time);
			
		} catch (IOException e) {
			
			e.printStackTrace();
			
			logger.debug("IOExeption occured :",ExceptionUtils.getStackTrace(e));
		}
    }

    //Alert when event of ServerUp is fired
    private void connectionLive() {        

        long timestamp = System.currentTimeMillis();
        
        configs.setTimestampLastRun(timestamp);
        
        boolean stateChanged = configs.getStatus().Running(timestamp, configs.getGraceInterval());
        
        if (stateChanged) {
        	
        	configs.alertServiceUp(timestamp);
        	
        	logger.info(String.format("Connection Live for %s", configs.getService()));
        }
    }

    // Alert when event of ServerDown is fired
    private void connectionDead() {        

        long timestamp = System.currentTimeMillis();
        
        configs.setTimestampLastRun(timestamp);
        
        boolean stateChanged = configs.getStatus().NotRunning(timestamp, configs.getGraceInterval());
        
        if (stateChanged) {
        	configs.alertServiceDown(timestamp);
        	
        	logger.info(String.format("Connection Dead for %s", configs.getService()));
        }
    }
    
}
