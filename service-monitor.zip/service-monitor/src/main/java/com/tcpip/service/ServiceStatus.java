package com.tcpip.service;

/** 
 *
 * @author W.P.Roshan
 * 
 * Tracks duration of service state RUNNING /NOT_RUNNING /UNKNOWN
 */
public class ServiceStatus {

    public enum Status {
        UNKNOWN,
        RUNNING,
        NOT_RUNNING;
    }

    private long stateTimestamp;
    private Status status = Status.UNKNOWN;

    /**
     * @param timestamp of the event
     * @param  afterNSeconds grace period, before temporary state change is considered as permanent.
     * @return true if server was Dead before, and now was changed to Live
     */
    public boolean Running(long timestamp, int afterNSeconds) {
        switch (status) {
            case UNKNOWN:
                status = Status.RUNNING;
                stateTimestamp = System.currentTimeMillis();
                return false;

            case NOT_RUNNING:
                
                if (stateTimestamp + afterNSeconds * 1000 <= timestamp) {
                    
                    status = Status.RUNNING;
                    stateTimestamp = timestamp;
                    return true;
                }
                return false;

            case RUNNING:
                
            default:
                return false;
        }
    }

    /**
     * @param timestamp of the event
     * @param afterNSeconds grace period before temporary state change is considered permanent
     * @return true if server was LIVE before, and now was switched OFF
     */
    public boolean NotRunning(long timestamp, int afterNSeconds) {
    	
        switch (status) {
            case UNKNOWN:
                status = Status.NOT_RUNNING;
                stateTimestamp = System.currentTimeMillis();
                return false;

            case RUNNING:
                
                if (stateTimestamp + afterNSeconds * 1000 <= timestamp) {
                    
                    status = Status.NOT_RUNNING;
                    stateTimestamp = timestamp;
                    return true;
                }
                return false;

            case NOT_RUNNING:
                
            default:
                return false;
        }
    }
}
