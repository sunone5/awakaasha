package com.tcpip.service;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author W.P.Roshan
 * 
 *         ServicePreparator singleton class for hold to map of service
 *         specifications
 * 
 *         There are 5 major Singleton Pattern Implementation Methodologies
 *         ----------------------------------------------------------------- 
 *         1.) Eager initialization 
 *         2.) Static block initialization 
 *         3.) Lazy Initialization 
 *         4.) Thread Safe Singleton 
 *         5.) Bill Pugh Singleton ( most widely used method :- multi-threaded & thread safe singleton
 * 
 */
public class ServicePreparator {

	private Map<String, ServiceSpecification> spec = new HashMap<String, ServiceSpecification>();
	
	// private constructor to avoid use default constructor
	private ServicePreparator() {
	}	

	// Singleton Pattern Bill Pugh implementation
	// -----------------------------------------------------------------------------
	private static class ServicePreparatorSingletonHelper {

		private static final ServicePreparator INSTANCE = new ServicePreparator();
	}

	public static ServicePreparator getSingletonInstance() {
		return ServicePreparatorSingletonHelper.INSTANCE;
	}

	public ServiceSpecification getSpecification(String name) {
		return spec.get(name);
	}
	//-------------------------------------------------------------------------------

	public Iterable<String> getServiceNames() {
		return spec.keySet();
	}

	public void reset() {
		spec.clear();
	}

	public void specificationAdd(ServiceSpecification serviceSpec) {
		spec.put(serviceSpec.getService(), serviceSpec);
	}

	public void specificationDelete(String name) {
		spec.remove(name);
	}

}
