package com.tcpip.service;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author W.P.Roshan
 * 
 *         ServiceSpecification class for configuration parameters
 * 
 */
public class ServiceSpecification {

	private String service;
	private String host;
	private int port;

	private boolean isRunning;
	private int pollingInterval;
	private int graceInterval;

	private long outageStart;
	private long outageEnd;

	private long timestampLastRun;

	private ServiceStatus status = new ServiceStatus();

	private List<ServiceObserver> observers = new ArrayList<ServiceObserver>();

	public ServiceSpecification(String service, String host, int port, boolean running, int pollingInterval,
			int graceInterval) {
		this.service = service;
		this.host = host;
		this.port = port;
		this.isRunning = running;
		this.pollingInterval = pollingInterval;
		this.graceInterval = graceInterval;
	}

	public String getService() {
		return service;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public boolean isRunning() {
		return isRunning;
	}

	public void setRunning(boolean running) {
		isRunning = running;
	}

	public int getGraceInterval() {
		return graceInterval;
	}

	public void setGraceInterval(int graceInterval) {
		this.graceInterval = graceInterval;
	}

	synchronized public long[] getOutageBoundaries() {
		return new long[] { outageEnd, outageStart };
	}

	public long getTimestampLastRun() {
		return timestampLastRun;
	}

	public void setTimestampLastRun(long timestampLastRun) {
		this.timestampLastRun = timestampLastRun;
	}

	public ServiceStatus getStatus() {
		return status;
	}

	public void setOutageEnd(long outageEnd) {
		this.outageEnd = outageEnd;
	}

	public void setOutageStart(long outageStart) {
		this.outageStart = outageStart;
	}

	synchronized public boolean isOutage(long currentTimestamp) {
		if (outageEnd > 0 && outageStart > 0) {
			return currentTimestamp >= outageEnd && currentTimestamp <= outageStart;
		}
		return false;
	}

	public synchronized int getPollingInterval() {
		if (graceInterval < pollingInterval) {
			return graceInterval;
		} else {
			return pollingInterval;
		}
	}

	public void setPollingInterval(int pollingInterval) {
		this.pollingInterval = pollingInterval;
	}

	synchronized public void observerAdd(ServiceObserver observer) {
		if (observer != null) {
			observers.add(observer);
		}
	}

	synchronized public void observerDelete(ServiceObserver observer) {
		if (observer != null) {
			observers.remove(observer);
		}
	}

	synchronized public void alertServiceUp(long timestamp) {
		for (ServiceObserver observer : observers) {
			observer.serviceUp(service, timestamp);
		}
	}

	synchronized public void alertServiceDown(long timestamp) {
		for (ServiceObserver observer : observers) {
			observer.serviceDown(service, timestamp);
		}
	}

	synchronized public void alertServiceUnknown(long timestamp) {
		for (ServiceObserver observer : observers) {
			observer.serviceUnknown(service, timestamp);
		}
	}
}
