package com.tcpip.service;

/**
 * @author W.P.Roshan 
 * 
 * Service Observer Interface : serviceUp / serviceDown / serviceUnknown
 * 
 * 
 */
public interface ServiceObserver {
	
	void serviceUp(String name, long timestamp);

	void serviceDown(String name, long timestamp);

	void serviceUnknown(String name, long timestamp);
}
