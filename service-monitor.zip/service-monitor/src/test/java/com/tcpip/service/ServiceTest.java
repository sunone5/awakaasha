package com.tcpip.service;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.logging.Logger;

/**
 * @author W.P.Roshan
 * 
 *         JUnit 5 Test Cases for ServiceMonitor Class
 */

@DisplayName("ServiceMonitorTest")
@RunWith(JUnitPlatform.class)
public class ServiceTest {

	public static final String SERVICE_A = "A";
	public static final String SERVICE_B = "B";
	public static final String SERVICE_C = "C";
	public static final String SERVICE_D = "D";

	static final Logger LOG = Logger.getLogger(ServiceTest.class.getName());

	private static ServiceMonitor service;

	ServiceObserver serviceObserver = new ServiceObserver() {
		@Override
		public void serviceUp(String name, long timestamp) {

			ServiceSpecification specification = service.preparator.getSpecification(name);

			LOG.info((String.format("%s service @ %s:%s is UP at %s", specification.getService(),
					specification.getHost(), specification.getPort(), String.valueOf(timestamp))));

		}

		@Override
		public void serviceDown(String name, long timestamp) {

			ServiceSpecification specification = service.preparator.getSpecification(name);

			LOG.info((String.format("%s service @ %s:%s is DOWN at %s", specification.getService(),
					specification.getHost(), specification.getPort(), String.valueOf(timestamp))));
		}

		@Override
		public void serviceUnknown(String name, long timestamp) {

			ServiceSpecification specification = service.preparator.getSpecification(name);

			LOG.info((String.format("%s service @ %s:%s is DOWN at %s", specification.getService(),
					specification.getHost(), specification.getPort(), String.valueOf(timestamp))));

		}
	};

	@BeforeAll
	protected static void setUp() throws Exception {
		service = new ServiceMonitor();
	}

	protected void tearDown() throws Exception {
		if (service != null) {
			service.preparator.reset();
			service.stopService();
			//service.stop();
			service = null;
		}
	}

	@Test
	public void testAllGoodConnections() throws Exception {

		LOG.info("testGoogleConnections");
		ServiceSpecification specification = new ServiceSpecification(SERVICE_A, "www.google.com", 80, true, 1, 3);
		service.preparator.specificationAdd(specification);

		// register serviceObserver
		for (String name : service.preparator.getServiceNames()) {
			ServiceSpecification sc = service.preparator.getSpecification(name);
			sc.observerAdd(serviceObserver);
		}

		if (!service.isAlive()) {
			service.start();
		}

		Thread.sleep(10 * 1000);
	}

	@Test
	public void testThreeGoodANDOneBad_Connections() throws Exception {

		LOG.info("testThreeGoodANDOneBad_Connections");

		ServiceSpecification specification = new ServiceSpecification(SERVICE_A, "www.google.com", 80, true, 1, 3);
		service.preparator.specificationAdd(specification);

		specification = new ServiceSpecification(SERVICE_B, "www.bbc.com", 80, true, 1, 3);
		service.preparator.specificationAdd(specification);

		specification = new ServiceSpecification(SERVICE_C, "www.cnn.com", 80, true, 1, 3);
		service.preparator.specificationAdd(specification);

		specification = new ServiceSpecification(SERVICE_D, "www.wrong.abracabra", 80, true, 1, 3);
		service.preparator.specificationAdd(specification);

		// register serviceObserver
		for (String name : service.preparator.getServiceNames()) {
			ServiceSpecification sc = service.preparator.getSpecification(name);
			sc.observerAdd(serviceObserver);
		}

		if (!service.isAlive()) {
			service.start();
		}

		Thread.sleep(20 * 1000);
	}

	@Test
	public void testConnectionsSwitch() throws Exception {

		LOG.info("testConnectionsSwitch");

		ServiceSpecification specification = new ServiceSpecification(SERVICE_A, "www.google.com", 80, true, 1, 3);
		service.preparator.specificationAdd(specification);

		specification = new ServiceSpecification(SERVICE_B, "www.cnn.com", 80, true, 1, 3);
		service.preparator.specificationAdd(specification);

		specification = new ServiceSpecification(SERVICE_C, "www.bbc.com", 80, true, 1, 3);
		service.preparator.specificationAdd(specification);

		specification = new ServiceSpecification(SERVICE_D, "www.kaputa.com", 80, true, 1, 3);
		service.preparator.specificationAdd(specification);

		// register listener
		for (String name : service.preparator.getServiceNames()) {
			ServiceSpecification sc = service.preparator.getSpecification(name);
			sc.observerAdd(serviceObserver);
		}

		if (!service.isAlive()) {
			service.start();
		}
		Thread.sleep(20 * 1000);

		specification = service.preparator.getSpecification(SERVICE_B);
		specification.setHost("www.youtube.com");
		specification.setPort(80);
		service.preparator.specificationAdd(specification);

		Thread.sleep(20 * 1000);
	}

	@Test
	public void testGraceThreshold() throws Exception {
		ServiceSpecification specification = new ServiceSpecification(SERVICE_A, "www.google.com", 80, true, 1, 3);
		specification.setPollingInterval(10);
		specification.setGraceInterval(5);
		assertEquals(specification.getPollingInterval(), 5);
	}

}
